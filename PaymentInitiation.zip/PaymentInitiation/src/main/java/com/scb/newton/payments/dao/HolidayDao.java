package com.scb.newton.payments.dao;

import com.scb.newton.payments.bean.Holiday;

public interface HolidayDao {

	boolean isHoliday(String date);

	Holiday getHoliday(String date);

}
