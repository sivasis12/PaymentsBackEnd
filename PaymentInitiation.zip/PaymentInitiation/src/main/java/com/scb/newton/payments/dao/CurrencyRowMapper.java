package com.scb.newton.payments.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.scb.newton.payments.bean.Currency;

public class CurrencyRowMapper implements RowMapper<Currency> {

	@Override
	public Currency mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		Currency curr=new Currency();
		curr.setCurrency(rs.getString("curr"));
		curr.setCurrencyId(rs.getInt("curr_id"));
		curr.setFormat(rs.getString("curr_format"));
		curr.setPrecison(rs.getInt("curr_precison"));
		return curr;
	}

}
