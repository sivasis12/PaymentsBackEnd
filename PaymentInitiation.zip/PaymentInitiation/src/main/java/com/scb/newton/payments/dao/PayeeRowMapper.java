package com.scb.newton.payments.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.scb.newton.payments.bean.Payee;

public class PayeeRowMapper implements RowMapper<Payee> {

	@Override
	public Payee mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		Payee payee=new Payee();
		payee.setPayeeId(rs.getInt("payee_id"));
		payee.setPayeeAccountNo(rs.getString("payee_account_no"));
		payee.setPayeeName(rs.getString("payee_name"));
		payee.setPayeeCurrency(rs.getString("payee_currency"));
		payee.setPayeeCity(rs.getString("payee_city"));
		payee.setPayeeBankCountry(rs.getString("payee_bank_country"));
		payee.setPayeeNickName(rs.getString("payee_nick_name"));
		payee.setPayeeLocalBankCode(rs.getString("payee_local_bank_code"));
		payee.setPayeeSwiftBankCode(rs.getString("payee_swift_bank_code"));
		payee.setPayeeBankName(rs.getString("payee_bank_name"));
		payee.setPayeeBankBranch(rs.getString("payee_bank_branch"));
		payee.setPayeeFavourite(rs.getBoolean("payee_favourite"));
		
		return payee;
		}

}
