package com.scb.newton.payments.bean;

public class CountryCurrency {
	private String ccid;
	private String countryCode;
	private String currency;
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
    
}
