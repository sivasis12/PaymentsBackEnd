package com.scb.newton.payments.bean;

public class Group {
	int groupId;
	String groupName;
	String countryCode;
	
	
	
	

}
