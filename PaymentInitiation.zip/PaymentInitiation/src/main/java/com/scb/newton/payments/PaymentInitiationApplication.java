package com.scb.newton.payments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentInitiationApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentInitiationApplication.class, args);
	}

}
