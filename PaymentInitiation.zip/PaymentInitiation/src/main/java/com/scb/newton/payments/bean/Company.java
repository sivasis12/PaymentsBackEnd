package com.scb.newton.payments.bean;

public class Company {

}
