package com.scb.newton.payments.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

import com.scb.newton.payments.bean.DebitInfom;
import com.scb.newton.payments.bean.Payee;
import com.scb.newton.payments.bean.User;

@Repository
public class UserLoginDaoImpl implements UserLoginDao {
	@Autowired
	
	JdbcTemplate usertemplate;
	
	

	@Override
	public User getUser(int userId) {
		// TODO Auto-generated method stub
		String userquery="SELECT * FROM p_user WHERE p_user_id=?";
		 return this.usertemplate.queryForObject(userquery, new UserMapper(),userId);
		
	}

	@Override
	public List<Payee> getPayee(int userId) {
		// TODO Auto-generated method stub
		String payeesearch="SELECT * FROM payee WHERE p_user_id=? ";
		RowMapper<Payee> payeemapper=new PayeeRowMapper();
		List<Payee> payees= this.usertemplate.query(payeesearch, payeemapper,userId);
		return payees;
		
	}

	@Override
	public int addPayee(Payee payee) {
		// TODO Auto-generated method stub
		
		 String sql="insert into payee(payee_id ,payee_name ,payee_account_no ,payee_currency ,payee_city ,payee_local_bank_code ,payee_swift_bank_code ,payee_bank_name ,payee_bank_branch ,payee_nick_name ,payee_bank_country ,payee_favourite) values(?,?,?,?,?,?,?,?,?,?,?,?);";
		 return this.usertemplate.update(sql,payee.getPayeeId(),payee.getPayeeName(),payee.getPayeeAccountNo(),payee.getPayeeCurrency(),payee.getPayeeCity(),payee.getPayeeLocalBankCode(),payee.getPayeeSwiftBankCode(),payee.getPayeeBankName(),payee.getPayeeBankBranch(),payee.getPayeeNickName(),payee.getPayeeBankCountry(),payee.isPayeeFavourite());
		
	}

	@Override
	public List<DebitInfom> getDebitInfo(int userId,int groupId) {
		// TODO Auto-generated method stub
		String debitsearch="select country_code,acc_no, acc_name, acc_curr,group_name, bank_id,permission from groups g inner join entitlement e on g.group_id = e.group_id inner join accounts a on a.acc_id = e.acc_id where p_user_id=? ;" ;
		 RowMapper<DebitInfom> debitinfomapper=new DebitInfomRowMapper();
		 List<DebitInfom> debitinfolist= this.usertemplate.query(debitsearch, debitinfomapper,userId);
			return debitinfolist;
		 
				
	}

	

	
	
}
