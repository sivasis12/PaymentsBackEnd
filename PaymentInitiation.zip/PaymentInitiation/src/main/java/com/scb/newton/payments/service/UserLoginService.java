package com.scb.newton.payments.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.scb.newton.payments.bean.DebitInfom;
import com.scb.newton.payments.bean.Payee;
import com.scb.newton.payments.bean.User;

public interface UserLoginService {

	

	User getUser(int userId);

	List<Payee> getPayee(int userId);

	int addPayee(Payee payee);

	List<DebitInfom> getDebitInfo(int userId,int groupId);

}
