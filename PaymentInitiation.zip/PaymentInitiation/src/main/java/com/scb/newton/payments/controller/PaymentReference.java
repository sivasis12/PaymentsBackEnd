package com.scb.newton.payments.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.scb.newton.payments.bean.User;
import com.scb.newton.payments.service.UserLoginService;

@RestController
public class PaymentReference {
	@Autowired
	UserLoginService usr;
	
	@GetMapping("api/payments/paymentid/{userId}")
	public String getPaymentId(@PathVariable int userId)
	{
		User user=usr.getUser(userId);
		String username=user.getUserName();       
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
		LocalDate localDate = LocalDate.now();
		System.out.println(dtf.format(localDate)); 
		return username.substring(0,3)+"/"+localDate;
	}
	
	

}
