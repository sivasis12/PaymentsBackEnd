package com.scb.newton.payments.dao;

import com.scb.newton.payments.bean.Currency;

public interface CurrencyDao {

	Currency getCurrencyFormat(String currency);

}
