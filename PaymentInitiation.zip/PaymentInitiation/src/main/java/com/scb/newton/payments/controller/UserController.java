package com.scb.newton.payments.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {
	
	//loginController
	
	//@get()
 
	
	

}
