package com.scb.newton.payments.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.scb.newton.payments.bean.Holiday;
import com.scb.newton.payments.service.HolidayService;

@RestController
public class HolidayController {
	
	@Autowired
	HolidayService hsr;
	
	@GetMapping("/holiday/{date}")
	public boolean isHoliday(@PathVariable String date)
	{
		return hsr.isHoliday(date);
		
	}
	@GetMapping("/holidayinfo/{date}")
	public Holiday getHoliday(@PathVariable String date)
	{
		return hsr.getHoliday(date);
		
	}
	
	
	

}
