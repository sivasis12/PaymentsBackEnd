package com.scb.newton.payments.dao;

import java.util.List;

import com.scb.newton.payments.bean.DebitInfom;
import com.scb.newton.payments.bean.Payee;
import com.scb.newton.payments.bean.User;

public interface UserLoginDao {

	User getUser(int userId);

	List<Payee> getPayee(int userId);

	int addPayee(Payee payee);

	List<DebitInfom> getDebitInfo(int userId,int groupId);

	

}
