package com.scb.newton.payments.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.newton.payments.bean.Holiday;
import com.scb.newton.payments.dao.HolidayDao;

@Service
public class HolidayServiceImpl implements HolidayService {
	
	@Autowired
	HolidayDao hdao;

	@Override
	public boolean isHoliday(String date) {
		// TODO Auto-generated method stub
		return hdao.isHoliday(date);
	}

	@Override
	public Holiday getHoliday(String date) {
		// TODO Auto-generated method stub
		return hdao.getHoliday(date);
	}

}
