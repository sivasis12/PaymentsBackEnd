package com.scb.newton.payments.bean;

public class Payee {
	private int payeeId;
	private String payeeName;
	private String payeeAccountNo;
	private String payeeCurrency;
	private String payeeCity;
	private String PayeeLocalBankCode;
	private String PayeeSwiftBankCode;
	private String payeeBankName;
	private String payeeBankBranch;
	private String payeeBankCountry;
	private String PayeeNickName;
	private boolean payeeFavourite;
	private int userId;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getPayeeId() {
		return payeeId;
	}
	public void setPayeeId(int payeeId) {
		this.payeeId = payeeId;
	}
	public String getPayeeName() {
		return payeeName;
	}
	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}
	public String getPayeeAccountNo() {
		return payeeAccountNo;
	}
	public void setPayeeAccountNo(String payeeAccountNo) {
		this.payeeAccountNo = payeeAccountNo;
	}
	public String getPayeeCurrency() {
		return payeeCurrency;
	}
	public void setPayeeCurrency(String payeeCurrency) {
		this.payeeCurrency = payeeCurrency;
	}
	public String getPayeeCity() {
		return payeeCity;
	}
	public void setPayeeCity(String payeeCity) {
		this.payeeCity = payeeCity;
	}
	public String getPayeeLocalBankCode() {
		return PayeeLocalBankCode;
	}
	public void setPayeeLocalBankCode(String payeeLocalBankCode) {
		PayeeLocalBankCode = payeeLocalBankCode;
	}
	public String getPayeeSwiftBankCode() {
		return PayeeSwiftBankCode;
	}
	public void setPayeeSwiftBankCode(String payeeSwiftBankCode) {
		PayeeSwiftBankCode = payeeSwiftBankCode;
	}
	public String getPayeeBankName() {
		return payeeBankName;
	}
	public void setPayeeBankName(String payeeBankName) {
		this.payeeBankName = payeeBankName;
	}
	public String getPayeeBankBranch() {
		return payeeBankBranch;
	}
	public void setPayeeBankBranch(String payeeBankBranch) {
		this.payeeBankBranch = payeeBankBranch;
	}
	public String getPayeeBankCountry() {
		return payeeBankCountry;
	}
	public void setPayeeBankCountry(String payeeBankCountry) {
		this.payeeBankCountry = payeeBankCountry;
	}
	public String getPayeeNickName() {
		return PayeeNickName;
	}
	public void setPayeeNickName(String payeeNickName) {
		PayeeNickName = payeeNickName;
	}
	public boolean isPayeeFavourite() {
		return payeeFavourite;
	}
	public void setPayeeFavourite(boolean payeeFavourite) {
		this.payeeFavourite = payeeFavourite;
	}
	


}
