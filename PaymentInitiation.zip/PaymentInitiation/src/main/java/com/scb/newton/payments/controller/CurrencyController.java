package com.scb.newton.payments.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.scb.newton.payments.bean.Currency;
import com.scb.newton.payments.service.CurrencyService;

@RestController
public class CurrencyController {
	@Autowired
	CurrencyService csr;
	
	@GetMapping("/currency/{currency}")
	public Currency getCurrencyFormat(@PathVariable String currency)
	{
		return csr.getCurrencyFormat(currency);
	}
	

}
