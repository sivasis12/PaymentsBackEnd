package com.scb.newton.payments.bean;

public class Currency {
	private int currencyId;
	private String currency;
	private String format;
	private int precison;
	public int getCurrencyId() {
		return currencyId;
	}
	public void setCurrencyId(int currencyId) {
		this.currencyId = currencyId;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getFormat() {
		return format;
	}
	public void setFormat(String format) {
		this.format = format;
	}
	public int getPrecison() {
		return precison;
	}
	public void setPrecison(int precison) {
		this.precison = precison;
	}

	
	
	

}
