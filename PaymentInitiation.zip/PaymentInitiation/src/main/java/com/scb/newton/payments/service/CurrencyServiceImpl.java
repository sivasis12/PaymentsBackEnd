package com.scb.newton.payments.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.newton.payments.bean.Currency;
import com.scb.newton.payments.dao.CurrencyDao;

@Service
public class CurrencyServiceImpl implements CurrencyService {
	
	@Autowired
	CurrencyDao cdao;

	@Override
	public Currency getCurrencyFormat(String currency) {
		// TODO Auto-generated method stub
		return cdao.getCurrencyFormat(currency) ;
	}

}
