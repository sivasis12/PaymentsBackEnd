package com.scb.newton.payments.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.scb.newton.payments.bean.Holiday;

@Repository
public class HolidayDaoImpl implements HolidayDao {
	
	@Autowired
	JdbcTemplate htemplate;
	
	

	@Override
	public boolean isHoliday(String date) {
		// TODO Auto-generated method stub
		String sql="SELECT COUNT(*) FROM holiday WHERE holiday_date=?";
		boolean exists=false;
		int count = htemplate.queryForObject(sql, new Object[] { date }, Integer.class);
        exists=count>0;
		return exists;
	
	}



	@Override
	public Holiday getHoliday(String date) {
		// TODO Auto-generated method stub
		String sql="SELECT * FROM holiday WHERE holiday_date=?";
		RowMapper<Holiday> holidaymapper=new HolidayRowMapper();
		 return  htemplate.queryForObject(sql, holidaymapper,date);

	}
	
	

}
