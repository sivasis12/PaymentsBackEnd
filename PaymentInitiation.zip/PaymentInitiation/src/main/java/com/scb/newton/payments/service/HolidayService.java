package com.scb.newton.payments.service;

import com.scb.newton.payments.bean.Holiday;

public interface HolidayService {

	boolean isHoliday(String date);

	Holiday getHoliday(String date);
	

}
