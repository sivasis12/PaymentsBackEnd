package com.scb.newton.payments.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.scb.newton.payments.bean.User;

public class UserMapper implements RowMapper<User> {

	public User mapRow(ResultSet rs, int rownumber) throws SQLException {  
		User e=new User();  
        e.setUserId(rs.getInt(1));  
        e.setUserName(rs.getString(2));  
        e.setPassword(rs.getString(3)); 
        return e;  
      
    }  

	

}
