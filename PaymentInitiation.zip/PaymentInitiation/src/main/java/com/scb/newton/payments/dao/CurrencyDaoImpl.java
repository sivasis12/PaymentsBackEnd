package com.scb.newton.payments.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.scb.newton.payments.bean.Currency;

@Repository
public class CurrencyDaoImpl implements CurrencyDao {
	
	@Autowired 
	JdbcTemplate ctemp;

	@Override
	public Currency getCurrencyFormat(String currency) {
		// TODO Auto-generated method stub
		
		String currquery="SELECT * FROM currency WHERE curr=? ";
		RowMapper<Currency> currMapper=new CurrencyRowMapper();
		return ctemp.queryForObject(currquery,  currMapper,currency);
	}

}
