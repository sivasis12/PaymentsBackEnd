package com.scb.newton.payments.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.scb.newton.payments.bean.Holiday;

public class HolidayRowMapper implements RowMapper<Holiday> {

	@Override
	public Holiday mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		Holiday holiday=new Holiday();
		holiday.setHolidayDate(rs.getString("holiday_date"));
		holiday.setHolidayName(rs.getString("holiday_name"));
		holiday.setCountryCode(rs.getString("country_code"));
		holiday.setCurrency(rs.getString("currency"));
		holiday.setHolidayId(rs.getInt("holiday_id"));
		return holiday;
	}

}
