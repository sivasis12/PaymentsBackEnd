package com.scb.newton.payments.bean;

public class Transaction {
	String paymentReference;
	String debitAccountNo;
	String debitGroupName;
	String payeeAccountNo;
	String payeeGroupName;
	double amount;
	String currency;
	String date;
	public String getPaymentReference() {
		return paymentReference;
	}
	public void setPaymentReference(String paymentReference) {
		this.paymentReference = paymentReference;
	}
	public String getDebitAccountNo() {
		return debitAccountNo;
	}
	public void setDebitAccountNo(String debitAccountNo) {
		this.debitAccountNo = debitAccountNo;
	}
	public String getDebitGroupName() {
		return debitGroupName;
	}
	public void setDebitGroupName(String debitGroupName) {
		this.debitGroupName = debitGroupName;
	}
	public String getPayeeAccountNo() {
		return payeeAccountNo;
	}
	public void setPayeeAccountNo(String payeeAccountNo) {
		this.payeeAccountNo = payeeAccountNo;
	}
	public String getPayeeGroupName() {
		return payeeGroupName;
	}
	public void setPayeeGroupName(String payeeGroupName) {
		this.payeeGroupName = payeeGroupName;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	

}
