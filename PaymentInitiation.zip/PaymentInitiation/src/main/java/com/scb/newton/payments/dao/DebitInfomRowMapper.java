package com.scb.newton.payments.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.scb.newton.payments.bean.DebitInfom;

public class DebitInfomRowMapper implements RowMapper<DebitInfom> {

	@Override
	public DebitInfom mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		DebitInfom debitinfo=new DebitInfom();
		debitinfo.setCountryCode(rs.getString("country_code"));
		debitinfo.setAccountNo(rs.getString("acc_no"));
		debitinfo.setAccountName(rs.getString("acc_name"));
		debitinfo.setAccountCurrency(rs.getString("acc_curr"));
		debitinfo.setGroupName(rs.getString("group_name"));
		debitinfo.setBank_id(rs.getString("bank_id"));
		debitinfo.setPermission(rs.getInt("permission"));
		return debitinfo;
	}

}
