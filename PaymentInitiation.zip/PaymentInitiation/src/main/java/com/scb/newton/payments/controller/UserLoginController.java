package com.scb.newton.payments.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.scb.newton.payments.bean.DebitInfom;
import com.scb.newton.payments.bean.Payee;
import com.scb.newton.payments.bean.User;
import com.scb.newton.payments.service.UserLoginService;

@RestController
public class UserLoginController{
	@Autowired
	UserLoginService usr;
	
	
	@GetMapping("api/payments/login/{userId}")
	public User getUser(@PathVariable int userId)
	{
		
		return usr.getUser(userId);
	}
	
	@GetMapping("api/payments/payee/{userId}")
	public List<Payee> getPayee(@PathVariable int userId)
	{
		return usr.getPayee(userId);
	}
	
	@PostMapping("api/payments/addPayee")
	public int addPayee(@RequestBody Payee payee )
	{
		System.out.println("payee"+payee.getPayeeAccountNo());
		return usr.addPayee(payee);
	}
	
	@GetMapping("api/payments/debitaccount/{userId}/{groupId}")
	public List<DebitInfom> getDebitInfo(@PathVariable int userId,@PathVariable int groupId)
	{
		
		return usr.getDebitInfo(userId,groupId);
	}
	
	
	
	
	
	
	
	

}
