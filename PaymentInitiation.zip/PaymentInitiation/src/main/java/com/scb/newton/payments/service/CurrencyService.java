package com.scb.newton.payments.service;

import com.scb.newton.payments.bean.Currency;

public interface CurrencyService {

	Currency getCurrencyFormat(String currency);

}
