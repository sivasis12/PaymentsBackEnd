package com.scb.newton.payments.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.newton.payments.bean.DebitInfom;
import com.scb.newton.payments.bean.Payee;
import com.scb.newton.payments.bean.User;
import com.scb.newton.payments.dao.UserLoginDao;

@Service
public class UserLoginServiceImpl implements UserLoginService {
	
	@Autowired
	UserLoginDao usdao;

	@Override
	public User getUser(int userId) {
		// TODO Auto-generated method stub
		return usdao.getUser(userId);
	}

	@Override
	public List<Payee> getPayee(int userId) {
		// TODO Auto-generated method stub
		return usdao.getPayee(userId);
	}

	@Override
	public int addPayee(Payee payee) {
		// TODO Auto-generated method stub
		return usdao.addPayee(payee);
		
	}

	@Override
	public List<DebitInfom> getDebitInfo(int userId,int groupId) {
		// TODO Auto-generated method stub
		return usdao.getDebitInfo(userId,groupId);
	}

}
